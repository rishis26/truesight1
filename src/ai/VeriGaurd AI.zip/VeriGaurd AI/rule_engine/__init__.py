"""
Rule engine package for VeriGuard AI threat detection system
"""

# This file makes the rule_engine directory a Python package