"""
Core threat processing logic for VeriGuard AI
Handles text processing, rule matching, and threat scoring
"""

import re
import json
from typing import List, Dict, Any
import os

class ThreatProcessor:
    """Processes text to detect potential threats based on configured rules"""
    
    def __init__(self, rules_file_path: str = 'rule_engine/rules.json'):
        """
        Initialize the threat processor with rules from JSON file
        
        Args:
            rules_file_path: Path to the JSON file containing threat rules
        """
        self.rules_file_path = rules_file_path
        self.keywords = {}
        self.patterns = []
        self._load_rules()
    
    def _load_rules(self) -> None:
        """Load threat detection rules from JSON file"""
        try:
            with open(self.rules_file_path, 'r') as f:
                rules_data = json.load(f)
                
            self.keywords = rules_data.get('keywords', {})
            self.patterns = rules_data.get('patterns', [])
            
        except FileNotFoundError:
            print(f"Warning: Rules file not found at {self.rules_file_path}")
            self.keywords = {}
            self.patterns = []
        except json.JSONDecodeError:
            print(f"Error: Invalid JSON in rules file {self.rules_file_path}")
            self.keywords = {}
            self.patterns = []
    
    def _clean_text(self, text: str) -> str:
        """
        Clean and normalize text for processing
        
        Args:
            text: Input text to clean
            
        Returns:
            Cleaned text in lowercase without punctuation
        """
        # Convert to lowercase
        text = text.lower()
        
        # Remove punctuation (keep alphanumeric and whitespace)
        text = re.sub(r'[^\w\s]', ' ', text)
        
        # Replace multiple spaces with single space
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def _find_keyword_matches(self, text: str) -> List[Dict[str, Any]]:
        """
        Find matches for keywords in the text
        
        Args:
            text: Cleaned text to search for keywords
            
        Returns:
            List of matched keywords with their details
        """
        matches = []
        words = text.split()
        
        for i, word in enumerate(words):
            if word in self.keywords:
                # Get context (previous and next words)
                start = max(0, i - 2)
                end = min(len(words), i + 3)
                context = ' '.join(words[start:end])
                
                matches.append({
                    'keyword': word,
                    'score': self.keywords[word],
                    'context': context
                })
        
        return matches
    
    def _find_pattern_matches(self, text: str) -> List[Dict[str, Any]]:
        """
        Find matches for regex patterns in the text
        
        Args:
            text: Cleaned text to search for patterns
            
        Returns:
            List of matched patterns with their details
        """
        matches = []
        
        for pattern_info in self.patterns:
            pattern = pattern_info.get('pattern', '')
            score = pattern_info.get('score', 0)
            
            if not pattern:
                continue
                
            try:
                regex = re.compile(pattern)
                pattern_matches = regex.finditer(text)
                
                for match in pattern_matches:
                    matches.append({
                        'keyword': match.group(),
                        'score': score,
                        'context': match.group()
                    })
            except re.error:
                print(f"Warning: Invalid regex pattern: {pattern}")
                continue
        
        return matches
    
    def process_text(self, text: str) -> Dict[str, Any]:
        """
        Process text to detect threats and calculate confidence score
        
        Args:
            text: Input text to analyze
            
        Returns:
            Dictionary with analysis results
        """
        # Clean the input text
        cleaned_text = self._clean_text(text)
        
        # Find keyword matches
        keyword_matches = self._find_keyword_matches(cleaned_text)
        
        # Find pattern matches
        pattern_matches = self._find_pattern_matches(cleaned_text)
        
        # Combine all matches
        all_matches = keyword_matches + pattern_matches
        
        # Calculate raw threat score
        raw_score = sum(match['score'] for match in all_matches)
        
        # Normalize score to percentage (capped at 100)
        from config import THREAT_SCORE_CAP, NORMALIZATION_FACTOR
        threat_confidence = min((raw_score / NORMALIZATION_FACTOR) * 100, 100)
        
        # Remove duplicate matches (keep first occurrence)
        unique_matches = []
        seen_keywords = set()
        for match in all_matches:
            if match['keyword'] not in seen_keywords:
                unique_matches.append(match)
                seen_keywords.add(match['keyword'])
        
        return {
            'success': True,
            'threat_confidence_score': round(threat_confidence, 2),
            'matched_keywords': unique_matches,
            'normalized_text': cleaned_text,
            'raw_score': raw_score
        }
    
    def reload_rules(self) -> None:
        """Reload rules from the JSON file (useful for updates)"""
        self._load_rules()