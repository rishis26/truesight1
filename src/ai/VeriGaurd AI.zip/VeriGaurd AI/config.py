"""
Configuration settings for VeriGuard AI Flask application
"""

import os

# Flask configuration
SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-key-for-hackathon-demo-only'

# Server configuration
DEBUG = True
HOST = '0.0.0.0'
PORT = 5000

# Threat analysis configuration
THREAT_SCORE_CAP = 100  # Maximum raw score before normalization
NORMALIZATION_FACTOR = 100  # Divisor for normalization
MIN_CONFIDENCE_THRESHOLD = 10  # Minimum score to be considered a potential threat

# File paths
RULES_FILE_PATH = 'rule_engine/rules.json'