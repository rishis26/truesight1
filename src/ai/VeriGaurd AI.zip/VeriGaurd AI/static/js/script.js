/**
 * Client-side JavaScript for VeriGuard AI application
 * Handles dynamic UI updates and API interactions
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Handle form submission with AJAX
    const threatForm = document.getElementById('threatForm');
    if (threatForm) {
        threatForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const submitBtn = document.getElementById('analyzeBtn');
            const originalText = submitBtn.innerHTML;
            const textInput = document.getElementById('threatText');
            const text = textInput.value.trim();
            
            if (!text) {
                showAlert('Please enter some text to analyze.', 'danger');
                return;
            }
            
            // Show loading state
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Analyzing...';
            submitBtn.disabled = true;
            
            // Call API
            fetch('/api/analyze', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ text: text })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    displayResults(data, text);
                } else {
                    showAlert('Analysis failed: ' + (data.error || 'Unknown error'), 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred during analysis. Please try again.', 'danger');
            })
            .finally(() => {
                // Restore button state
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            });
        });
    }
    
    // Function to display results
    function displayResults(result, originalText) {
        // Create results container if it doesn't exist
        let resultsContainer = document.getElementById('resultsContainer');
        if (!resultsContainer) {
            resultsContainer = document.createElement('div');
            resultsContainer.id = 'resultsContainer';
            resultsContainer.className = 'mt-4';
            threatForm.after(resultsContainer);
        }
        
        // Determine threat level class
        let threatLevel = 'success';
        let threatText = 'Low Threat';
        if (result.threat_confidence_score >= 70) {
            threatLevel = 'danger';
            threatText = 'High Threat';
        } else if (result.threat_confidence_score >= 30) {
            threatLevel = 'warning';
            threatText = 'Medium Threat';
        }
        
        // Highlight keywords in the original text
        let highlightedText = originalText;
        result.matched_keywords.forEach(match => {
            const regex = new RegExp('\\b' + escapeRegExp(match.keyword) + '\\b', 'gi');
            highlightedText = highlightedText.replace(regex, '<span class="threat-keyword">$&</span>');
        });
        
        // Generate matched keywords list HTML
        let keywordsHtml = '';
        if (result.matched_keywords.length > 0) {
            keywordsHtml = '<h5>Matched Keywords:</h5><ul class="list-group mb-3">';
            result.matched_keywords.forEach(match => {
                keywordsHtml += `<li class="list-group-item d-flex justify-content-between align-items-center">
                    <span>${match.keyword}</span>
                    <span class="badge bg-warning rounded-pill">+${match.score}</span>
                </li>`;
            });
            keywordsHtml += '</ul>';
        } else {
            keywordsHtml = '<div class="alert alert-info">No threat keywords detected.</div>';
        }
        
        // Build results HTML
        resultsContainer.innerHTML = `
            <div class="card result-card">
                <div class="card-header bg-${threatLevel} text-white">
                    <h4 class="mb-0">Analysis Results</h4>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5>Threat Confidence Score</h5>
                            <div class="score-display display-4 text-${threatLevel} fw-bold">
                                ${result.threat_confidence_score}%
                            </div>
                            <div class="badge bg-${threatLevel} fs-6">${threatText}</div>
                        </div>
                        <div class="col-md-6">
                            <h5>Confidence Level</h5>
                            <div class="confidence-meter mb-2">
                                <div class="confidence-fill confidence-${threatLevel}" 
                                     style="width: ${result.threat_confidence_score}%"></div>
                            </div>
                            <small>0% - No threat detected | 100% - High confidence of threat</small>
                        </div>
                    </div>
                    
                    ${keywordsHtml}
                    
                    <h5>Analyzed Text with Threat Highlights:</h5>
                    <div class="analysis-text">${highlightedText}</div>
                </div>
            </div>
        `;
        
        // Scroll to results
        resultsContainer.scrollIntoView({ behavior: 'smooth' });
    }
    
    // Function to show alert messages
    function showAlert(message, type) {
        // Remove existing alerts
        const existingAlerts = document.querySelectorAll('.alert-dismissible');
        existingAlerts.forEach(alert => alert.remove());
        
        // Create new alert
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        // Insert alert
        const container = document.querySelector('.container');
        container.insertBefore(alertDiv, container.firstChild);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                const bsAlert = new bootstrap.Alert(alertDiv);
                bsAlert.close();
            }
        }, 5000);
    }
    
    // Helper function to escape regex special characters
    function escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
});