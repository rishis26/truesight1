"""
Main Flask application for VeriGuard AI - Phase 1 (MVP)
A hoax bomb detection system with rule-based threat analysis
"""

from flask import Flask, render_template, request, jsonify
from rule_engine.processor import ThreatProcessor
import json

# Initialize Flask application
app = Flask(__name__)

# Load configuration
app.config.from_pyfile('config.py')

# Initialize threat processor
threat_processor = ThreatProcessor()

@app.route('/')
def index():
    """Render the main input form page"""
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    """
    Analyze text input for threats
    Accepts form data with 'text' field
    Returns rendered results page
    """
    text = request.form.get('text', '')
    
    if not text:
        return render_template('index.html', error="Please enter text to analyze")
    
    # Process the text for threats
    result = threat_processor.process_text(text)
    
    return render_template('results.html', result=result, original_text=text)

@app.route('/api/analyze', methods=['POST'])
def api_analyze():
    """
    API endpoint for threat analysis
    Accepts JSON: {'text': 'input text here'}
    Returns JSON response with analysis results
    """
    data = request.get_json()
    
    if not data or 'text' not in data:
        return jsonify({
            'success': False,
            'error': 'Missing text field in request'
        }), 400
    
    text = data['text']
    
    # Process the text for threats
    result = threat_processor.process_text(text)
    
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=app.config['DEBUG'], host=app.config['HOST'], port=app.config['PORT'])